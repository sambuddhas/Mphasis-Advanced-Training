package com.bookstore.entity;

import java.sql.Timestamp;

public class Orders 
{
	int Order_Id;
	String Address;
	long Phone_No;
	String Cust_Name;
	String Order_Date;
	int Quantity;
	
	public Orders(String address, long phone_no, String cust_name) {
		super();
		this.Address = address;
		this.Phone_No = phone_no;
		this.Cust_Name = cust_name;
		
	}
	public Orders(int order_id, String address, long phone_no,String cust_name,String order_date, int quantity) {
		this.Order_Id = order_id;
		this.Address = address;
		this.Phone_No = phone_no;
		this.Cust_Name = cust_name;
		this.Order_Date =order_date;
		this.Quantity = quantity;
	}
	public int getOrder_Id() {
		return Order_Id;
	}
	public void setOrder_Id(int order_id) {
		this.Order_Id = order_id;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		this.Address = address;
	}
	public long getPhone_No() {
		return Phone_No;
	}
	public void setPhone_No(long phone_no) {
		this.Phone_No = phone_no;
	}
	public String getCust_Name() {
		return Cust_Name;
	}
	public void setCust_Name(String name) {
		this.Cust_Name = name;
	}
	public String getOrder_Date() {
		return Order_Date;
	}
	public void setOrder_Date(String order_date) {
		this.Order_Date = order_date;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		this.Quantity = quantity;
	}
	@Override
	public String toString() {
		return "Orders [order_id=" + Order_Id + ", address=" + Address + ", phone_no=" + Phone_No + ", cust_name=" + Cust_Name
				+ ", order_date=" + Order_Date + ", quantity=" + Quantity + "]";
	}

	
}
