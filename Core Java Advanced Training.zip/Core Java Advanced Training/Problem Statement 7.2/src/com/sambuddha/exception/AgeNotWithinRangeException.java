package com.sambuddha.exception;
public class AgeNotWithinRangeException extends Exception{
	
	public AgeNotWithinRangeException(String mssg) {
		
		super(mssg);
	}

}